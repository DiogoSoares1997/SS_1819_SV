function [ c , e] = SystemS( a, b, d )
c = a .* b;
e = d+c;

% valormedioC=mean(c);
% valormedioE=mean(e);
% %%EnergiaC=int(c.^2,-0.001, 0.001);
% EnergiaE=0;
% PotenciaC=0;
% PotenciaE=0;
end

